import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Load and preprocess content from the dataset
def load_content(file_path='ag_news.csv'):
    df = pd.read_csv(file_path)
    content = df['Description'].tolist()  # Extract descriptions as content
    return content

# Load content data
content = load_content()

# Vectorize content using TF-IDF
vectorizer = TfidfVectorizer(stop_words='english')
tfidf_matrix = vectorizer.fit_transform(content)

# Function to filter content based on user requirements and recommend similar items
def get_filtered_recommendations(user_query, top_n=3):
    # Transform the user query to the same vector space
    query_vec = vectorizer.transform([user_query])
    cosine_similarities = cosine_similarity(query_vec, tfidf_matrix).flatten()

    # Get top N most relevant articles based on the user query
    relevant_indices = cosine_similarities.argsort()[-top_n:][::-1]
    return [(content[idx], cosine_similarities[idx]) for idx in relevant_indices]
