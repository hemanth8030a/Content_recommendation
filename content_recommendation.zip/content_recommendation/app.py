from flask import Flask, render_template, request
from content_data import content, get_filtered_recommendations

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/recommend', methods=['POST'])
def recommend():
    user_query = request.form['user_query']  # Get user query from form input
    recommendations = get_filtered_recommendations(user_query)
    return render_template('index.html', user_query=user_query, recommendations=recommendations)

if __name__ == '__main__':
    app.run(debug=True)
